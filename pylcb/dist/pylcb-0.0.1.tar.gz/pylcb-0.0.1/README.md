couchbase-lib
==============

Tower3 version of the couchbase python client.

